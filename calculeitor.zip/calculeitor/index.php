<?php 
    ini_set('display_errors', 1);
    error_reporting(E_ALL);

	if ($_SERVER['REQUEST_METHOD'] === 'POST') {
		$number1 = $_POST['number1'];
		$number2 = $_POST['number2'];
		$operator = $_POST['operator'];

		if(validadeFields($number1, $number2, $operator) && validateDivisionByZero($number2, $operator)) {
			switch($operator){
				case 'sum':
					$result = $number1 + $number2;
					break;
				case 'sub':
					$result = $number1 - $number2;
					break;
				case 'mult':
					$result = $number1 * $number2;
					break;
				case 'div':
					$result = $number1 / $number2;
					break;
				default:
					$result = null;
			}
		}
	}

	function validadeFields($number1, $number2, $operator){
		if(!is_numeric($number1) || !is_numeric($number2)){
			$GLOBALS['error_msg'] = "Tá tirando seu comédia? Tem que preencher os números!!!";
			$GLOBALS['video'] = "https://www.youtube.com/embed/h09p0IGiKaE?si=dnjKZ2wbx7yWjTg2&autoplay=1";
			return false;
		}
		
		if(!isset($operator) || $operator == ''){
			$GLOBALS['error_msg'] = "Se tu não escolher a operação não vai dar certo. Me ajuda a te ajudar!";
			$GLOBALS['video'] = "https://www.youtube.com/embed/h09p0IGiKaE?si=dnjKZ2wbx7yWjTg2&autoplay=1";
			return false;
		}
		return true;
	}

	function validateDivisionByZero($number2, $operator){
		if($operator == 'div' && $number2 == 0){
			$GLOBALS['error_msg'] = "Faltou na aula de matemática né, mizeráve.. Divisão por zero cara?";
			$GLOBALS['video'] = "https://www.youtube.com/embed/h09p0IGiKaE?si=dnjKZ2wbx7yWjTg2&autoplay=1";
			return false;
		}
		return true;
	}

?>
<!DOCTYPE html>
<html lang="pt-br">
<head>
	<meta charset="UTF-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<title>Calculadora JS</title>
	<link rel="stylesheet" type="text/css" href="style.css">
	<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous">
</head>
<body>

	<div class="container text-center">
		<form action="#" method="POST" id="formCalc">
			<div class="row title-box">
				<div class="col-md-12">
					<img style = 'height:300px; width:300px;' src='logo.jpeg' alt="Logo" class="logo">
				</div>
				<div class="col-md-12">
					<h3 class="title">Calculadora PHP</h3> <span>(melhor com som ligado)</span>
				</div>
			</div>


			<?=isset($GLOBALS['video'])? '
				<div class="video">
				<iframe width="560" height="315" src="'.$GLOBALS['video'].'" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" allowfullscreen></iframe>
				</div>
			' : '' ?>

			<?=isset($GLOBALS['error_msg'])? '
			<div class="row error-box">
				<div class="col-sm-12 com-md-12">
					<h4>
					' . $GLOBALS['error_msg'] . '
					</h4>
				</div>
			</div>'
			: '' ?>


			<div class="row form-box">
				<div class="col-sm-4 col-md-4 form-floating input-gp">
					<input step="any" type="number" class="form-control text-center" value="<?=isset($_POST['number1']) ? $_POST['number1'] : '' ?>" autofocus id="number1" name="number1" placeholder="1º número" />
					<label for="number1">1º número</label>
				</div>

				<div class="col-sm-2 col-md-2 form-floating input-gp">
					<select class="form-select text-center" id="operator" name="operator">
						<option value=""></option>
						<option value="sum" <?=isset($_POST['operator']) && $_POST['operator'] == 'sum' ? 'selected': '' ?>>+</option>
						<option value="sub" <?=isset($_POST['operator']) && $_POST['operator'] == 'sub' ? 'selected': '' ?>>-</option>
						<option value="mult" <?=isset($_POST['operator']) && $_POST['operator'] == 'mult' ? 'selected': '' ?>>*</option>
						<option value="div"> <?=isset($_POST['operator']) && $_POST['operator'] == 'div' ? 'selected': '' ?>/</option>
					</select>
					<label for="operator">Operação</label>
				</div>

				<div class="col-sm-4 col-md-4 form-floating input-gp">
					<input step="any" type="number" class="form-control text-center" value="<?=isset($_POST['number2']) ? $_POST['number2'] : '' ?>"  id="number2" name="number2" placeholder="2º número" />
					<label for="number2">2º número</label>
				</div>

				<div class="col-sm-2 col-md-2 input-gp">
					<button class="btn btn-success btn-lg" id="btnCalcular" name="btnCalcular"> Calcular </button>
				</div>
			</div>                
				<div class="row result-box" id="result-box" <?= isset($result) ? '' : 'style="display: none"' ?>>
				<div class="col-md-1 col-sm-1"></div>
				<div class="col-md-4 col-sm-4">
					<h3 class="result-title">Resultado: </h3>
				</div>
				<div class="col-md-4 col-sm-4 input-gp">
					<input step="any" type="number" disabled class="form-control text-center" value="<?=isset($result) ? $result : '' ?>" id="result" name="result"/>
				</div>
				<div class="col-md-2 col-sm-2">
					<button onclick="location.replace(location.href)" class="btn btn-warning btn-lg" id="btnReset"> Reset </button>
				</div>
			</div>


		</form>
	</div>

</body>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-C6RzsynM9kWDrMNeT87bh95OGNyZPhcTNXj1NW7RuBCsyN/o0jlpcV8Qyq46cDfL" crossorigin="anonymous"></script>
<!--script type="text/javascript" src="script.js"></!--script-->
</html>